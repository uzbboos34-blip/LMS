/*
    Global object
        1. global
        2. process
        3. setTimeOut
        4. setInterval
        5. __dirname | process.cwd()
        6. __filename
        7. console
        8. exports 
        9. module
        10.require
    modules
        kodlarni alohida filelarga bo'lish
    CommonJs -> 2015 gacha bo'lgan modulelar boshqaruvi
        module exports = {}
        require()
    ES module -> 2015 dan keyin chiqgan module sintaksist
        1. export
        2. export default
        import ... from "..." 
    global module
        http, fs -> file system
*/
// const express = require("express")

// console.log(console)

// const {plus2, plus} = require("./modules/plus")

// const a = 23
// const b = 2
// console.log(plus(a,b),plus2(a,b))

// const [,,a,b] = process.argv

// import m from "./modules/minus.js"

// console.log(m(a,b))

// import { plus } from "./modules/plus.js"

// const [,,option,a,b] = process.argv

// const func = {
//     plus: (a,b) => plus(a,b),
//     minus: (a,b) => minus(a,b),
//     devide: (a,b) => devide(a,b),
//     multiple: (a,b) => multiple(a,b),
// }

// console.log(func[option](a,b))

import fs from "fs"

// fs.readFile("database/users.json","utf-8",(error,data) => {
//     console.log(JSON.parse(data))
// })

let users = fs.readFileSync("database/users.json","utf-8")
users = JSON.parse(users)

const newUser = {
    id:users.length ? users[users.length-1].id + 1 : 1,
    name:"Vali"
}
users.push(newUser)

fs.writeFileSync("database/users.json",JSON.stringify(users,null,4))
console.log("Malumot yozildi")


/*
 node users add vali
 node users delete id 1
 node users get all-> barcha userlar chiqarilsin ->. conslole.table bilan chiqarish
 node users get id 2 -> aynan 2 - idli userni malumotlari chiqsin
 node users put id 2 name salim
 */
