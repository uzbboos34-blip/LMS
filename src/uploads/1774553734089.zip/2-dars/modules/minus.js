export default function minus1(a,b){
    return a - b
}




// export {
//     minus1,
//     minus2,
//     minus3
// }